#include <stdio.h>
#include "all.h"

void copy(char from[], char to[]){
	int i = 0;
	while((to[i] = from[i]) != '\0') ++i;
}
