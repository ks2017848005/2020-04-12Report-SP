#ifndef __ALL_H__
#define __ALL_H__

#include <stdio.h>
#include <string.h>

#define MAXLINE 100

void copy(char from[], char to []);
char * mygets(char *buf, size_t size);

#endif
